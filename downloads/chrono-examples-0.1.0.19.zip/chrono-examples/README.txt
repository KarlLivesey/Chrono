Chrono 0.1.0.19 examples

Install 04tgK000000KFNtQAO first and assign Chrono Flow User.
From the directory containing chrono-examples, deploy:
sf project deploy start --metadata-dir chrono-examples/metadata --target-org your-org --wait 20

Optional saved demo data (test org only; these perform DML):
sf apex run --target-org your-org --file chrono-examples/scripts/seed-example-holiday.apex
sf apex run --target-org your-org --file chrono-examples/scripts/seed-example-hours.apex

Run the two scripts in separate transactions. Open Setup > Flows, search Chrono,
then Debug an example or inspect its actions in Flow Builder.
